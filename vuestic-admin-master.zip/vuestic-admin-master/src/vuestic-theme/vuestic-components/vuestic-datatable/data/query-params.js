export default {
  sort: 'sort',
  page: 'page',
  perPage: 'per_page',
}
