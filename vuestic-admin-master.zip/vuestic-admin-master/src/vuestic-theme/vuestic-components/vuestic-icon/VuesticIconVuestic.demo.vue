<template>
  <div class="demo-container">
    <div class="demo-container__item">
      <vuestic-icon-vuestic/>
    </div>
  </div>
</template>

<script>
import VuesticIconVuestic from './VuesticIconVuestic.vue'

export default {
  components: {
    VuesticIconVuestic,
  },
}
</script>
